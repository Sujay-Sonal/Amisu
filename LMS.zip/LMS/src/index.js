

import React from 'react';
import ReactDOM from 'react-dom';


import './index.css';
import Login from './Login';
//import Registration from './Registration';
import reportWebVitals from './reportWebVitals';
//import SchoolCreation from './SchoolCreation';
//import School_Creation_Chain from './School_Creation_Chain';

ReactDOM.render(
  <React.StrictMode>
  <Login/>
   {/* <Registration />
   <SchoolCreation/>*/}
    
  </React.StrictMode>,
  document.getElementById('root')
);


reportWebVitals();