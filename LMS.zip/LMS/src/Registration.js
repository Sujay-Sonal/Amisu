import React ,{Component} from 'react';


class Registration extends Component {
    constructor(props) {
        super(props)
        this.state = {
            
            Class:'',
            Academic_session:'',
            firstName: '',
            middle_name:'',
            lastName: '',
            gender: '',
            dob:'',
            category:'',
            mother_tounge:'',
            blood_group:'',
            religion:'',
            nationality:'',
            uid:'',
            email:'',
            mobile:'',
            alternate_number:'',
            address:'',
            location:'',
            pin:'',
            address_same:'',
            permanent_add:'',
            single_parent:'',
            father:'',
            mother:'',
            guardian:'',
            other_guardian:'',
            prev_school_name:'',
            board:'',
            marks:'',
            medium:'',
            academic_from:'',
            academic_to:'',
            refered:'',
            dist_from_school:'',
            single_child:'',
            staff_ward:'',
            girl_child:'',
            single_girl_child:'',
            others:'',
            
            
            
            

            
        }
        this.handleSubmit = this.handleSubmit.bind(this)
}
Classhandler = (event) => {
    this.setState({
        Class: event.target.value
    })
}
Academic_sessionhandler = (event) => {
    this.setState({
        Academic_session: event.target.value
    })
}
firsthandler = (event) => {
    this.setState({
        firstName: event.target.value 
    })
}
middle_namehandler = (event) => {
    this.setState({
        middle_name: event.target.value
    })
}
lastNamehandler = (event) => {
    this.setState({
        lastName: event.target.value
    })
}
dobhandler = (event) => {
    this.setState({
        dob: event.target.value
    })
}
categoryhandler = (event) => {
    this.setState({
        category: event.target.value
    })
}
mother_toungehandler = (event) => {
    this.setState({
        mother_tounge: event.target.value
    })

}
blood_grouphandler = (event) => {
        this.setState({
            blood_group: event.target.value
        })
    }
religionhandler = (event) => {
        this.setState({
            religion: event.target.value
        })
    }
nationalityhandler = (event) => {
        this.setState({
            nationality: event.target.value
        })
    }
uidhandler = (event) => {
        this.setState({
            uid: event.target.value
        })
    }
    genderhandler = (event) => {
        this.setState({
            gender: event.target.value
        })
    }
    emailhandler = (event) => {
        this.setState({
            email: event.target.value
        })
    }
    mobilehandler = (event) => {
        this.setState({
            mobile: event.target.value
        })
    }
    alternate_numberhandler = (event) => {
        this.setState({
            alternate_number: event.target.value
        })
    }
    addresshandler = (event) => {
        this.setState({
            address: event.target.value
        })
    }
    locationhandler = (event) => {
        this.setState({
            location: event.target.value
        })
    }
    pinhandler = (event) => {
        this.setState({
            pin: event.target.value
        })
    }
    address_samehandler = (event) => {
        this.setState({
            address_same: event.target.value
        })
    }
    permanent_addhandler = (event) => {
        this.setState({
            permanent_add: event.target.value
        })
    }
    single_parenthandler = (event) => {
        this.setState({
            single_parent: event.target.value
        })
    }
    fatherhandler = (event) => {
        this.setState({
            father: event.target.value
        })
    }
    motherhandler = (event) => {
        this.setState({
            mother: event.target.value
        })
    }
    guardianhandler = (event) => {
        this.setState({
            guardian: event.target.value
        })
    }
    other_guardianhandler = (event) => {
        this.setState({
            other_guardian: event.target.value
        })
    }
    prev_school_namehandler = (event) => {
        this.setState({
            prev_school_name: event.target.value
        })
    }
    boardhandler = (event) => {
        this.setState({
            board: event.target.value
        })
    }
    markshandler = (event) => {
        this.setState({
            marks: event.target.value
        })
    }
    mediumhandler = (event) => {
        this.setState({
            medium: event.target.value
        })
    }
    academic_fromhandler = (event) => {
        this.setState({
            academic_from: event.target.value
        })
    }
    academic_tohandler = (event) =>{
        this.setState({
            academic_to: event.target.value
        })
    }
    referedhandler = (event) => {
        this.setState({
            refered: event.target.value
        })
    }
    dist_from_schoolhandler = (event) => {
        this.setState({
            dist_from_school: event.target.value
        })
    }
    single_childhandler = (event) => {
        this.setState({
             single_child: event.target.value
        })
    }
    staff_wardhandler = (event) => {
         this.setState({
            staff_ward: event.target.value
        })
    }
    girl_childhandler = (event) => {
            this.setState({
                girl_child: event.target.value
        })
    }
    single_girl_childhandler =(event)=>{
        this.setState({
            single_girl_child: event.target.value
        })
    }
    othershandler = (event) => {
        this.setState({
            others: event.target.value
        })
    }
    handleSubmit = (event) => {
        alert(`${this.state.firstName}  ${this.state.lastName} Registered Successfully`)
        console.log(this.state);
        this.setState({
            Class:'',
            Academic_session:'',
            firstName: '',
            middle_name:'',
            lastName: '',
            gender: '',
            dob:'',
            category:'',
            mother_tounge:'',
            blood_group:'',
            religion:'',
            nationality:'',
            uid:'',
            email:'',
            mobile:'',
            alternate_number:'',
            address:'',
            location:'',
            pin:'',
            address_same:'',
            permanent_add:'',
            single_parent:'',
            father:'',
            mother:'',
            guardian:'',
            other_guardian:'',
            prev_school_name:'',
            board:'',
            marks:'',
            medium:'',
            academic_from:'',
            academic_to:'',
            refered:'',
            dist_from_school:'',
            single_child:'',
            staff_ward:'',
            girl_child:'',
            single_girl_child:'',
            others:'',
            
        })
        event.preventDefault()
    }
    render() {
        return (
            <div className='regform'>
               
                <h1 style={{color: "blue"}}>Saakshar User Registration</h1>
                <form onSubmit={this.handleSubmit}>
                <div className='main'>
                    <h3 style={{color: "red"}}>Admission sought in</h3>
                    <div id='admission'>
                    <div>
                    <label>Class  :  </label>
                    <select onChange={this.Classhandler} defaultValue="Select Your Class">
                        <option defaultValue>Select Your Class</option>
                        <option value=" Nursery">Nursery</option>
                        <option value=" LKG">LKG</option>
                        <option value=" MKG">MKG</option>
                        <option value=" 1">Class 1</option>
                        <option value=" 2">Class 2</option>
                        <option value=" 3">Class 3</option>
                        <option value=" 4">Class 4</option>
                        <option value=" 5">Class 5</option>
                        <option value=" 6">Class 6</option>
                        <option value=" 7">Class 7</option>
                        <option value=" 8">Class 8</option>
                        <option value=" 9">Class 9</option>
                        <option value=" 10">Class 10</option>
                        <option value=" 11">Class 11</option>
                        <option value=" 12">Class 12</option>
                    </select>
                    </div>
                    <br />
                    <div>
                    <label>Academic Session  :  </label>
                    <select onChange={this.Academic_sessionhandler} defaultValue="Select Your Class">
                        <option defaultValue>Academic Session</option>
                        <option value="Refer School Licence Module">Refer School Licence Module</option>
                        <option value="2021-2022">2021-2022</option>
                        <option value="2022-2023">2022-2023</option>
                        <option value="2023-2024">2023-2024</option>
                        <option value="2024-2025">2024-2025</option>
                        <option value="2025-2026">2025-2026</option>
                    </select>
                    </div>
                    <br />
                    </div>
                    </div>
                    <div className =' Student'>
                    <h3 style={{color: "red"}}>Student Informations</h3>
                    <div>
                    <label>First Name  :  </label>
                    <input type='text' value={this.state.firstName} placeholder='First Name' minLength='2' onChange={this.firsthandler} required autoCapitalize='chatacters'/></div><br />
                    <div>
                    <label>Middle Name  :  </label>
                    <input type='text' value={this.state.middle_name} placeholder='Middle Name' onChange={this.middle_namehandler} /></div><br />
                    <div>
                    <label>Last Name  :  </label>
                    <input type='text' value={this.state.lastName} placeholder='Last Name'  minLength='2' onChange={this.lastNamehandler} /></div><br />
                    <div>
                    <label>Gender  :  </label>
                    <select onChange={this.genderhandler} defaultValue="Select Gender">
                        <option defaultValue>Select Gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="Other">Prefer Not To Say</option>
                    </select>
                    </div>
                    <br /><br/>
                    <div>
                    <label>D.O.B  :  </label>
                    <input type='date' value={this.state.dob} onChange={this.dobhandler} required/></div><br />
                    
                    <div><label>Category  :  </label>
                    <select onChange={this.categoryhandler} defaultValue="Select Your Category">
                        <option defaultValue>Category</option>
                        <option value="None">None</option>
                        <option value="Divyang">Divyang</option>
                        <option value="Special">Special</option>
                       
                    </select></div><br />
                    <div>
                    <label>Mother Tounge  :  </label>
                    <input type='text' value={this.state.mother_tounge} placeholder='Mother Tounge'  minLength='3' onChange={this.mother_toungehandler} /><br />
                    </div><br />
                    <div>
                    <label>Bloog Group  :  </label>
                    <select onChange={this.blood_grouphandler} defaultValue="Select Your Bloog Group">
                        <option defaultValue>Bloog Group</option>
                        <option value="A +">A +</option>
                        <option value="A -">A -</option>
                        <option value="B +">B +</option>
                        <option value="B -">B -</option>
                        <option value="AB +">AB -</option>
                        <option value="AB +">AB -</option>
                        <option value="O +">O +</option>
                        <option value="O -">O -</option>
                        <option value="Bombay Blood Group">Bombay Blood Group</option>
                    </select></div><br />
                    <div>
                    <label>Religion  :  </label>
                    <input type='text' value={this.state.religion} placeholder='Religion' onChange={this.religionhandler} /></div><br />
                    <div>
                    <label>Nationality  :  </label>
                    <input type='text' value={this.state.nationality} placeholder='From Which Country You Belongs' onChange={this.nationalityhandler} /><br />
                    </div>
                    </div>
                    <div className ='Commuication'>
                    <h3 style={{color: "red"}}>Communication Details</h3>
                    <div> <label>Email  :  </label>
                    <input type='email' value={this.state.email} placeholder='Email Id' onChange={this.emailhandler} required/></div><br />
                    <div><label>Mobile Number  :  </label>
                    <input type='number' value={this.state.mobile} placeholder='Mobile Number' onChange={this.mobilehandler} min='1000000000' max='9999999999' required /></div><br />
                    <div><label>Alternate Mobile Number  :  </label>
                    <input type='number' value={this.state.alternate_number} placeholder='Alternate Number' min='6000000000' max='9999999999' onChange={this.alternate_numberhandler} maxLength='10' /></div><br />
                    <div><label>Present Address  :  </label>
                    <textarea value={this.state.address} placeholder='Present Postal Address'  minLength='10' onChange={this.addresshandler} required/></div><br />
                    <div><label>Location (Near By)  :  </label>
                    <textarea value={this.state.location} placeholder='Landmark' onChange={this.locationhandler} /></div><br />
                    <div><label>PIN :  </label>
                    <input type='number' value={this.state.pin} placeholder='Zip' min='100000' max='999999'onChange={this.pinhandler} required/></div><br />
                    <div><label>Is Present and Permanent Address are Same  :  </label>
                    <select onChange={this.address_samehandler} defaultValue="Yes/No">
                        <option defaultValue>Yes/No</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select></div><br />
                    <div><label>Permanent Address  :  </label>
                    <textarea value={this.state.permanent_add} placeholder='Permanent Postal Address' onChange={this.permanent_addhandler} required/><br />
                    </div>
                    </div>
                    <div className='Guardian'>
                        <h3 style={{color: "red"}}>Father / Mother / Guardian Details</h3>
                        <div><label>Single Parent  :  </label>
                    <select onChange={this.single_parenthandler} defaultValue="Father/Mother">
                        <option defaultValue>Father/Mother</option>
                        <option value="Father">Father</option>
                        <option value="Mother">Mother</option>
                    </select></div><br />
                    <div><label>Father :  </label>
                    <input type='text' value={this.state.father} placeholder='Father'  minLength='2'  onChange={this.fatherhandler} required/></div><br />
                    <div><label>Mother :  </label>
                    <input type='text' value={this.state.mother} placeholder='Mother'  minLength='2'  onChange={this.motherhandler} required/></div><br />
                    <div><label>Guardian  :  </label>
                    <select onChange={this.guardianhandler} defaultValue="Father/Mother/Others">
                        <option defaultValue>Father/Mother/Others</option>
                        <option value="Father">Father</option>
                        <option value="Mother">Mother</option>
                        <option value="Others">Others</option>
                        </select></div><br />
                        <div><label>Other Guardian :  </label>
                    <input type='text' value={this.state.other_guardian} placeholder='Other Guardian' onChange={this.other_guardianhandler}/></div><br />
                    </div>
                    <div className='Previous'>
                        <h3 style={{color: "red"}}>Previous School Details</h3>
                        <div><label>Previous School Name :  </label>
                    <input type='text' value={this.state.prev_school_name} placeholder='Previous School Name' minLength='3'  onChange={this.prev_school_namehandler}/></div><br />
                    <div><label>Board  :  </label>
                    <select onChange={this.boardhandler} defaultValue="Board">
                        <option defaultValue>Board</option>
                        <option value="CBSE">CBSE</option>
                        <option value="ICSE">ICSE</option>
                        <option value="Others">Others</option>
                        </select></div><br />
                        <div><label>Marks :  </label>
                    <input type='number' value={this.state.marks} placeholder='Percent/CGPA' onChange={this.markshandler}/></div><br />
                    <div><label>Medium of Instruction  :  </label>
                    <select onChange={this.mediumhandler} defaultValue="Medium of Instruction">
                        <option defaultValue>Medium of Instruction</option>
                        <option value="English">English</option>
                        <option value="Hindi">Hindi</option>
                        <option value="Others">Others</option>
                        </select></div><br />
                        <div><label>Previous Academic From:  </label>
                    <input type='date' value={this.state.academic_from} placeholder='Previous Academic' onChange={this.academic_fromhandler}/></div><br />
                    <div> <label>Previous Academic To:  </label>
                    <input type='date' value={this.state.academic_to} placeholder='Previous Academic' onChange={this.academic_tohandler}/></div><br />
                    <div> <label>Refered :  </label>
                    <input type='text' value={this.state.refered} placeholder='Refered By (If any)' onChange={this.referedhandler}/></div><br />
                    <br/>
                    
                        <h3 style={{color: 'red'}}>Others Details</h3>
                        <div><label>Distance From School  :  </label>
                    <select onChange={this.dist_from_schoolhandler} defaultValue="Select_Distance">
                    <option defaultValue>Select Distance</option>
                        <option value="0-2 Kms">0-2 Kms</option>
                        <option value="2-5 Kms">2-5 Kms</option>
                        <option value="5-8 Kms">5-8 Kms</option>
                        <option value="Above 8 Kms">Above 8 Kms</option>                       
                    </select></div><br />
                    <div><label>Single Child :  </label>
                    <select onChange={this.single_childhandler} defaultValue="Yes/No">
                    <option defaultValue>Yes/No</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                    </select></div><br />
                    <div><label>Staff Ward  :  </label>
                    <select onChange={this.staff_wardhandler} defaultValue="Yes/No">
                    <option defaultValue>Yes/No</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select></div><br />
                    <div><label>Girl Child :  </label>
                    <select onChange={this.girl_childhandler} defaultValue="Yes/No">
                    <option defaultValue>Yes/No</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select></div><br />
                    <div><label>Single Girl Child :  </label>
                    <select onChange={this.single_girl_childhandler} defaultValue="Yes/No">
                    <option defaultValue>Yes/No</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select></div><br />
                    <div><label>Anything Else :  </label>
                    <textarea value={this.state.others} placeholder='Anything else you want to tell us :' onChange={this.othershandler}/></div><br />

                    </div>
                    <br/>

                    <div className = 'button'>
                    <br />
                    <br />
                    <input type ='submit' value="Register"/>
                    <br />
                    <br />
                    <br />
                    </div>

                </form>
                
            
            
            
                </div>
        )
    }
}
    
    
export default Registration