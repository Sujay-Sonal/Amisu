import React , {Component} from 'react'

class School_Creation extends Component{
    constructor(props){
        super(props)
        this.state={
            license_type:'',
            school_name:'',
            school_code:'',
            chain_school:'',
            board:'',
            region:'',
            address:'',
            country:'',
            email:'',
            phone:'',
            website:'',
            academic_range:'',
            license_start:'',
            license_end:'',
            grace_period:'',
            mac:'',
            number_of_class:'',
            count:'',
            number_of_student:'',
            total_user:'',
        }
        this.handleSubmit=this.handleSubmit.bind(this)
    }
    license_typehandler = (event) => {
        this.setState({
            license_type: event.target.value
        })
    }
    school_namehandler = (event) => {
        this.setState({
            school_name: event.target.value
        })
    }
    school_codehandler = (event) => {
        this.setState({
            school_code: event.target.value
        })
    }
    chain_schoolhandler = (event) => {
        this.setState({
            chain_school: event.target.value
        })
    }
    boardhandler = (event) => {
        this.setState({
            board: event.target.value
        })
    }
    regionhandler = (event) => {
        this.setState({
            region: event.target.value
        })
    }
    addresshandler = (event) => {
        this.setState({
            address: event.target.value
        })
    }
    countryhandler = (event) => {
        this.setState({
            country: event.target.value
        })
    }
    emailhandler = (event) => {
        this.setState({
            email: event.target.value
        })
    }
    phonehandler = (event) => {
        this.setState({
            phone: event.target.value
        })
    }
    websitehandler = (event) => {
        this.setState({
            website: event.target.value
        })
    }
    academic_rangehandler = (event) => {
        this.setState({
            academic_range: event.target.value
        })
    }
    license_starthandler = (event) => {
        this.setState({
            license_start: event.target.value
        })
    }
    license_endhandler = (event) => {
        this.setState({
            license_end: event.target.value
        })
    }
    grace_periodhandler = (event) => {
        this.setState({
            grace_period: event.target.value
        })
    }
    machandler = (event) => {
        this.setState({
            mac: event.target.value
        })
    }
    number_of_classhandler = (event) => {
        this.setState({
            number_of_classes: event.target.value
        })
    }
    counthandler = (event) => {
        this.setState({
            count: event.target.value
        })
    }
    number_of_studenthandler = (event) => {
        this.setState({
            number_of_student: event.target.value
        })
    }
    total_userhandler = (event) => {
        this.setState({
            total_user: event.target.value
        })
    }
    handleSubmit = (event) => {
        //alert(`${this.state.firstName}  ${this.state.lastName} Registered Successfully`)
        //console.log(this.state);
        this.setState({
            license_type:'',
            school_name:'',
            school_code:'',
            chain_school:'',
            board:'',
            region:'',
            address:'',
            country:'',
            email:'',
            phone:'',
            website:'',
            academic_range:'',
            license_start:'',
            license_end:'',
            grace_period:'',
            mac:'',
            number_of_class:'',
            count:'',
            number_of_student:'',
            total_user:'',
        })
        event.preventDefault()

}
render(){
    return(
        <div className='School Creation'>
        <div className="radio">
      
    </div>
               
        <h1 style={{color: "blue"}}>School Creation</h1>
        <form onSubmit={this.handleSubmit}>
        <div className='main'>
            <h3 style={{color: "red"}}>Basic Informations</h3>
            <div id='information'>
            <label>
        <input type="radio" value="Chain School" 
                      checked={this.state.selectedOption === 'Chain School'} 
                      onChange={this.handleOptionChange} /> Chain School</label> 

         <label>
        <input type="radio" value="School" 
                      checked={this.state.selectedOption === ' School'} 
                      onChange={this.handleOptionChange} />  School</label><br/><br/>
                      
            <label>License  :  </label>
            <select onChange={this.license_typehandler} defaultValue="License Type">
                <option defaultValue>Select Your License Type</option>
                <option value=" Licensed">Licensed</option>
                <option value=" Demo">Demo</option>
                
            </select><br />
            <label>School Name  :  </label>
            <input type='text' value={this.state.school_name} placeholder='Name of School' minLength='2' onChange={this.school_namehandler} required /><br />
            <label> School Code  :  </label>
            <input type='text' value={this.state.school_code} placeholder='Code of School' minLength='2' onChange={this.school_codehandler} required /><br />
            <label>Academic Session  :  </label>
            <select onChange={this.chain_schoolhandler} defaultValue="Select Your School">
                <option defaultValue>School Name</option>
                <option value="Refer School Licence Module">Refer List : School List Module</option>
            </select><br />
            
            </div>
            </div>
            <label>Category  :  </label>
            <select onChange={this.boardhandler} defaultValue="Board">
                <option defaultValue>Board</option>
                <option value="None">None</option>
                <option value="IB">Special</option>
                <option value="CBSE">Disabled</option>
                <option value="ICSE">Special</option>
                <option value="STATE">Special</option>
                </select><br />

                <select onChange={this.regionhandler} defaultValue="Region">
                <option defaultValue>Region</option>
                <option value="East">East</option>
                <option value="West">West</option>
                <option value="North">North</option>
                <option value="South">South</option>
                <option value="International">International</option>
                </select><br />

                <label>Address of School :  </label>
            <textarea value={this.state.address} placeholder=' Address'  minLength='10' onChange={this.addresshandler} required/><br />

            <label>Country :  </label>
            <input type='country' value={this.state.country} placeholder=' Country Name'  minLength='10' onChange={this.countryhandler} required/><br />

            <label>Email  :  </label>
            <input type='email' value={this.state.email} placeholder='Email Id' onChange={this.emailhandler} required/><br />
            <label> Number  :  </label>
            <input type='number' value={this.state.phone} placeholder='Phone/Mobile Number' onChange={this.phonehandler} min='1000000000' max='9999999999' required /><br />
            <label>website  :  </label>
            <input type='website' value={this.state.website} placeholder='Website Link' onChange={this.websitehandler} required/><br />

            <div className =' Student'>
            <h3 style={{color: "red"}}>Academic Range</h3>
            <label>Academic Range  :  </label>
            <select onChange={this.academic_rangehandler} defaultValue="Academic Range">
                <option defaultValue>Academic Range</option>
                <option value="Academic Range">Academic Range</option>
                <option value="Academic Range">Academic Range</option>
                <option value="Academic Range">Academic Range</option>
            </select><br /><br/>
            <label>License Start  :  </label>
            <input type='date' value={this.state.license_start} onChange={this.license_starthandler} required/><br />
            <label>License End  :  </label>
            <input type='date' value={this.state.license_end} onChange={this.license_endhandler} required/><br />

            <label>Grace Period  :  </label>
            <input type='text' value={this.state.grace_period} placeholder='Grace Period (In Days)' minLength='2' onChange={this.grace_periodhandler} required autoCapitalize='chatacters'/><br />
            <label>MAC Add  :  </label>
            <input type='text' value={this.state.mac} placeholder='Mac Address' onChange={this.machandler} /><br />
            <label>Number of Class :  </label>
            <input type='number' value={this.state.number_of_class} placeholder='Number' min='10' max='' onChange={this.number_of_classhandler} required/><br />

            <label>Number of Students :  </label>
            <input type='number' value={this.state.number_of_student} placeholder='Number' min='10' max='' onChange={this.number_of_studenthandler} required/><br />
            <label>Total User :  </label>
            <input type='number' value={this.state.total_user} placeholder='Zip' min='10' max=''onChange={this.total_userhandler} required/><br />
            
            
            
            
            <label>Anything Else :  </label>
            <textarea value={this.state.others} placeholder='Anything else you want to tell us :' onChange={this.othershandler}/><br />

            </div>
            <br/>

            <div className = 'button'>
            <br />
            <br />
            <input type ='submit' value="Save"/>
            <br />
            <br />
            <br />
            </div>

        </form>
        
    
    
    
        </div>
    )
}
        
}

export default School_Creation