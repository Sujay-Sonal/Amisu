

import React from 'react';
import { Switch, Route } from 'react-router-dom';
import Login from '../Login.js';
//import Registration from '../Registration.js';
//import SchoolCreation from './SchoolCreation';
//import School_Creation_Chain from './School_Creation_Chain';

const App = () => {


  return (
    <div>
      <Switch>
      <Route path='/' component={Login} />
        <Route path='/' component={Registration} />
        <Route path='/' component={SchoolCreation} />
        
      </Switch>
    </div>
  )
}

export default App;